Installation instructions for modified ezusb.sys:

1. Unplug any EZ-USB devices that are attached to the computer.
2. Copy the ezusb.sys file to %WINDOWSPATH%/system32/drivers, overwriting the
   existing ezusb.sys file
3. Plug back in the devices.

Readout size limit of this version: 384 kilobytes (192k words)
